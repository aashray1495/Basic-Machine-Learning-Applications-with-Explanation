#Univariate Regreesion - House Size vs House Price
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import matplotlib.pyplot as plt

dat = pd.read_excel('Housing.xlsx')

X= dat[['House Size (sq.ft.)']['Number of Rooms']['Year of Construction']]
Y= dat['House Price']

plt.scatter(X,Y)
plt.xlabel('House Size(sq ft.)')
plt.ylabel('House Price')
plt.axis([0,2500, 0, 1500000])
plt.show()

#Applying Ordinary Linear Regression

X1 = sm.add_constant(X)
reg = sm.OLS(Y,X1).fit()

print(reg.summary()) #This will output all the calculated data

#Alternate Method: Displaying only certain values

slope, intercept, rval, pval, std_err = stats.linregress(X,Y)
print('Slope is ', slope)
print('Intercept is ', intercept)
print('R Value is ', rval)
print('P Value is ', pval)
print('Standard Error is ', std_err)
