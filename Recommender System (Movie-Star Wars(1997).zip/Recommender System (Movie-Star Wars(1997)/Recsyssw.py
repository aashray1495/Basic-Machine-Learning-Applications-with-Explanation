#Movie Recommender System - Star Wars (1997)
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

cols_name = ['user_id', 'item_id', 'rating', 'timestamp'] #name all columns

df = pd.read_csv('u.data', sep='\t', names=cols_name) #Reading subset of data det
muvi = pd.read_csv('Movie_Id_Titles')
df = pd.merge(df,muvi, on='item_id') #merge movie data set with column names

ratings = pd.DataFrame(df.groupby('title')['rating'].mean()) #Displaying average rating of each movie
ratings['number']= pd.DataFrame(df.groupby('title')['rating'].count()) #Creating column for number of ratings
print(ratings.head())

muvimat=df.pivot_table(index='user_id',columns='title',values='rating') #using pivot table to create a matrix of movies for each user_id 
print('muvimat matrix:')
print(muvimat.head())

sw_user_ratings=muvimat['Star Wars (1977)'] #extracting user ratings for Star Wars (1977)
similar2sw= muvimat.corrwith(sw_user_ratings) #Running correlation function to find similarly rated movies
corr_sw=pd.DataFrame(similar2sw,columns=['Correlation']) #converting array into DataFrame
corr_sw.dropna(inplace=True) #Dropping all null values(user ratings not present for every user id)

corr_sw=corr_sw.join(ratings['number'])
print('Recommended Movies:')
print(corr_sw[corr_sw['number']>100].sort_values('Correlation', ascending=False))