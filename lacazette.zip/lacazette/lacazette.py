#Is Lacazette the answer to Wenger's problems?

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

df=pd.read_csv('arsenalfwd.csv')
df.head()
dfn= df.drop('Name', axis=1)#Dropping name column

dfn.head()

from sklearn.cross_validation import train_test_split
X=dfn
y=dfn['WengerIn']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size= 0.3, random_state=101)

from sklearn.neighbors import KNeighborsClassifier
KNN = KNeighborsClassifier(n_neighbors=1)
KNN.fit(X_train, y_train)
pred= KNN.predict(X_test)
from sklearn.metrics import classification_report 
print(classification_report(y_test,pred))

a = sns.pairplot(dfn)
plt.show(a)

b=sns.jointplot(x=dfn['Goals Scored'], y=dfn['WengerIn'])
plt.show(b)


c=sns.jointplot(x=dfn['Goals Per Match'], y=dfn['WengerIn'])
plt.show(c)

#Looks like Lacazette will be good