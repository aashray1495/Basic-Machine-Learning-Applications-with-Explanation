#SVM example with huge data set
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

cov = pd.read_csv('covtype.csv')
cov.info()

from sklearn.cross_validation import train_test_split
X = cov.drop(['Cover_Type'], axis=1)#Setting X by removing label to examines
y = cov['Cover_Type']#Setting y equivalent to label 'Cover_Type'

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=101)

#Applying SVC directly
from sklearn.svm import SVC
mod = SVC()
mod.fit(X_train,y_train)
pred = mod.predict(X_test)

from sklearn.metrics import classification_report, confusion matrix
print(classification_report(y_test,pred))
print('\n')
print(confusion_matrix(y_test,pred))

#Applying GridSearch method to find best parameters for SVC()
from sklearn.grid_search import GridSearchCV
param_grid={'C':[0.1,1,10,100,1000], 'gamma':[1,0.1,0.01,0.001]}
grid= GridSearchCV(SVC(),param_grid,verbose=3)
grid.fit(X_train,y_train)#Large dataset: Will take a lot of time

print(gird.best_params_)

grid_predictions=grid.predict(X_test)
print('confusion_matrix w/GridSearch:')
print(confusion_matrix(y_test,grid_predictions))
print('classification_report w/GridSearch:')
print(classification_report(y_test,grid_predictions))