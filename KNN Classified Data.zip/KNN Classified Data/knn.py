#KNN Classified DataSet Example

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report 
from sklearn.metrics import confusion_matrix
from sklearn.cross_validation import train_test_split


df=pd.read_csv('Classified Data', index_col=0)#Classified DataSet with unknown column names and values

from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(df.drop('TARGET CLASS', axis=1)) #Drop TARGETCLASS from X
scaled_features = scaler.transform(df.drop('TARGET CLASS', axis=1)) #Apply ScalerTransform to convert values into 1D array of mean and SD since columns are unknown
df_feat=pd.DataFrame(scaled_features, columns=df.columns[:-1]) #Converting 1D array into a DataFrame

#Applying KNN with k=1
X=df_feat
y=df['TARGET CLASS']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size= 0.3, random_state=101)
from sklearn.neighbors import KNeighborsClassifier
KNN = KNeighborsClassifier(n_neighbors=1)
KNN.fit(X_train, y_train)
pred = KNN.predict(X_test)
print('pred values:')
print(pred)
print(confusion_matrix(y_test,pred))
print('\n')
print(classification_report(y_test,pred))

#Applying Elbow Method to find better suited value for k
error_rate=[]
for i in range(1,40):
        knn= KNeighborsClassifier(n_neighbors=i)
        knn.fit(X_train, y_train)
        pred_i=knn.predict(X_test)
        error_rate.append(np.mean(pred_i != y_test))

plt.figure(figsize=(10,6))
plt.plot(range(1,40), error_rate, marker='o', markerfacecolor='red', markersize='10')
plt.title('Error Rate vs k')
plt.xlabel('k Value')
plt.ylabel('Error Rate')
plt.show()

#Applying KNN with n=17
knn=KNeighborsClassifier(n_neighbors=17)
knn.fit(X_train,y_train)
pred=knn.predict(X_test)

print(confusion_matrix(y_test,pred))
print(classification_report(y_test,pred))