#Decision Tree vs Random Forest
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('loan_data.csv')

#Getting rid of categorical values in purpose
cat_feats=['purpose']
final_data=pd.get_dummies(df,columns=cat_feats,drop_first=True)
final_data.head()

#Training model
from sklearn.cross_validation import train_test_split
X= final_data.drop('not.fully.paid', axis=1)
y=final_data['not.fully.paid']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=101)

#Applying Dtree
from sklearn.tree import DecisionTreeClassifier
dtree= DecisionTreeClassifier()
dtree.fit(X_train, y_train)
pred = dtree.predict(X_test)
from sklearn.metrics import classification_report, confusion_matrix
print('classification_report for Decision Tree:')
print(classification_report(y_test,pred))
print('confusion_matrix for Decision Tree:')
print(confusion_matrix(y_test,pred))

#Applying RndForest
from sklearn.ensemble import RandomForestClassifier
rfc=RandomForestClassifier(n_estimators=300)
rfc.fit(X_train,y_train)
predr=rfc.predict(X_test)
print('classification_report for Random Forest:')
print(classification_report(y_test,predr))
print('confusion_matrix for Random Forest:')
print(confusion_matrix(y_test,predr))