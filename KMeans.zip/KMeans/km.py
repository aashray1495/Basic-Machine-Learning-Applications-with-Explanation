#Unsupervised Learning using KMeans Clustering
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

colg = pd.read_csv('College_Data', index_col=0)#Set first column as index

colg[colg['Grad.Rate']>100]
colg['Grad.Rate']['Cazenovia College']=100#Reset Grad.Rate=100 for school having Grad.Rate>100

from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=2)# 2 centres: one for Private schools and other for public schools
kmeans.fit(colg.drop('Private', axis=1))# Drop Private column as it contains labels and KMeans is supposed to be unsupervised
print(kmeans.cluster_centers_)
#Function to convert Categorical into numeric values
def converter(private):
    if private=='Yes':
       return 1
    else: 
       return 0

colg['Cluster']= colg['Private'].apply(converter)#Create a new column Clusters with converted numeric values

from sklearn.metrics import confusion_matrix, classification_report
print(classification_report(colg['Cluster'],kmeans.labels_))
print('\n')
print(confusion_matrix(colg['Cluster'],kmeans.labels_))